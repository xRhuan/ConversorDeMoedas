package br.rhuan.conversordemoedas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private EditText edtReais;
    private Button btnConverter;
    private TextView txtValorDolar, txtValorEuro, txtValorBitcoin, txtValorOuro;
    public double valorDolar, valorEuro, valorBitcoin, valorReais, valorOuro;
    public String textoResult = "";
    DecimalFormat d = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarComponentes();

        btnConverter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valorReais = Double.parseDouble(edtReais.getText().toString());
                valorDolar = Double.parseDouble(d.format(valorReais * 0.18));
                valorEuro = Double.parseDouble(d.format(valorReais * 0.15));
                valorOuro = Double.parseDouble(d.format(valorReais * 0.000316));
                valorBitcoin = Double.parseDouble(d.format(valorReais * 0.0000039));
                txtValorDolar.setText(String.valueOf(valorDolar)+"$");
                txtValorEuro.setText(String.valueOf(valorEuro)+"€");
                txtValorOuro.setText(String.valueOf(valorOuro)+"Kg");
                txtValorBitcoin.setText(String.valueOf(valorBitcoin)+"₿");
            }
        });
    }

    private void inicializarComponentes() {
        edtReais = findViewById(R.id.edtReais);
        btnConverter = findViewById(R.id.btnConverter);
        txtValorDolar = findViewById(R.id.txtValorDolar);
        txtValorEuro = findViewById(R.id.txtValorEuro);
        txtValorBitcoin = findViewById(R.id.txtValorBitcoin);
        txtValorOuro = findViewById(R.id.txtValorOuro);
    }


}